const categories = {children: "ילדים", adults: "מבוגרים", comics: "קומיקס", recipes: "מתכונים"};

module.exports = categories;