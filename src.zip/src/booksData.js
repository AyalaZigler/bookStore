const booksData = [
  {
    name: "דודי ואודי",
    author: "שרה ליאון",
    price: 100,
    discount: 20,
    b_count: 5,
    category: ["children", "adults"],
    rating: 1,
    ratingCount:2
  },
  {
    name: "מבשלים בכיף",
    price: 80,
    discount: 0,
    b_count: 2,
    category: ["recipes"],
    rating: 2,
    ratingCount: 1
  },
  {
    name: "לאה ואליהו",
    author: "מנוחה פוקס",
    price: 60,
    discount: 0,
    b_count: 2,
    category: ["children", "comics"],
    rating: 3,
    ratingCount: 2
  }
];

module.exports = booksData;