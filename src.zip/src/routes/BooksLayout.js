import { Link, Outlet } from 'react-router-dom';

const BooksLayout = () => {
  return (
    <div>
      {/* החלק הקבוע שיופיע בכל דף */}
      <h1 className="app-title">חנות ספרים</h1>
      
      {/* תפריט ניווט */}
      <nav style={{ textAlign: 'center', margin: '20px', padding: '20px', backgroundColor: '#f0f0f0', borderRadius: '10px' }}>
        <Link to="/books" style={{ margin: '0 15px', fontSize: '18px', color: 'blue', textDecoration: 'none' }}>
          כל הספרים
        </Link>
        <Link to="/books/add" style={{ margin: '0 15px', fontSize: '18px', color: 'green', textDecoration: 'none' }}>
          הוסף ספר חדש
        </Link>
        <Link to="/" style={{ margin: '0 15px', fontSize: '18px', color: 'orange', textDecoration: 'none' }}>
          חזרה לדף הבית
        </Link>
      </nav>
      
      {/* כאן יופיע התוכן המשתנה לפי הניתוב */}
      <Outlet />
    </div>
  );
};

export default BooksLayout;