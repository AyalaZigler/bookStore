import { Link } from 'react-router-dom';

const HomePage = () => (
  <div>
    <h1 className="app-title">🏠 ברוכים הבאים לחנות הספרים שלנו</h1>
    <div style={{ textAlign: 'center', margin: '50px' }}>
      <div style={{ 
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        color: 'white',
        padding: '30px',
        borderRadius: '15px',
        maxWidth: '500px',
        margin: '0 auto'
      }}>
        <h2>🎉 ברוכים הבאים למערכת ניהול הספרים!</h2>
        <p style={{ fontSize: '18px', margin: '20px 0' }}>
          כאן תוכלו לנהל את אוסף הספרים שלכם, להוסיף ספרים חדשים ולדרג אותם
        </p>
        
        <div style={{ marginTop: '30px' }}>
          <Link 
            to="/books" 
            style={{ 
              display: 'inline-block',
              fontSize: '20px', 
              color: 'white',
              backgroundColor: '#4CAF50',
              padding: '15px 30px',
              margin: '10px',
              borderRadius: '25px',
              textDecoration: 'none',
              fontWeight: 'bold'
            }}
          >
            📚 כנסו לחנות הספרים
          </Link>
        </div>
      </div>
    </div>
  </div>
);

export default HomePage;