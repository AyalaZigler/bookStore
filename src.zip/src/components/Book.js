import './Book.css';
import { useState } from 'react';
import categories from '../categories';

function Book(props) {

  const {name, price, discount, author, category, b_count, rating, onRemove, onRate} = props;

  const [liked, setLiked] = useState(false);
  const [count, setCount] = useState(b_count);
  const [localRating, setLocalRating] = useState(rating || 1);
  const [hoveredRating, setHoveredRating] = useState(null);

  const hasDiscount = discount > 0;
  const finalPrice = hasDiscount ? price * (1 - discount / 100) : price;

  const buyClick = () => {
    console.log(`הוספת את "${name}" לסל`);
  };

  const doLike = () => {
    setLiked(prev => !prev);
  };

  const addCount = () => {
    setCount(prevCount => prevCount + 1);
  };

  const deleteBook = () => {
    if (window.confirm("האם למחוק את הספר?")) {
      onRemove(name);
    }
  };

  let containerClass = 'book-container';
  if (b_count === 0) containerClass += ' book-out-of-stock';
  else if (hasDiscount) containerClass += ' book-discount';

  return (
    <div className={containerClass}>
      <h2>{name}</h2>
      <p dir="rtl">מחיר: {price} ₪</p>
      {hasDiscount && <p dir="rtl">מחיר לאחר הנחה: {finalPrice.toFixed(2)} ₪</p>}
      <p dir="rtl">סופר: {author}</p>

      {category && category.length > 0 && (
        <div dir="rtl">
          <p>קטגוריות:</p>
          <ul className="category-list">
            {category.map((key, idx) => (<li key={idx}>{categories[key]}</li>))}
          </ul>
        </div>
      )}

      {b_count > 0 ? (
        <>
          <p dir="rtl">מספר ספרים במלאי: {count}</p>

          {/* דירוג ממוצע + כוכבים */}
          <p dir="rtl">דירוג ממוצע: {rating?.toFixed(2)}</p>
          <div className="stars" dir="rtl">
            {[1, 2, 3, 4, 5].map((star) => (
              <span
                key={star}
                className={`star ${star <= (hoveredRating || localRating) ? 'filled' : ''}`}
                onClick={() => {
                  setLocalRating(star);
                  onRate(name, star);
                }}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(null)}
              >
                ★
              </span>
            ))}
          </div>
          <br />
          {/* כפתורי פעולה – בתחתית */}
          <div className="button-row">
            <button className="like-button" onClick={doLike}>
              {liked ? "❤️" : "🩶"}
            </button>
            <button className="buy-button" onClick={buyClick}>
              להוספה לסל
            </button>
            <button className="addCount-button" onClick={addCount}>
              הוספה למלאי
            </button>
            <button className="delet-button" onClick={deleteBook}>
              מחיקת הספר
            </button>
          </div>
        </>
      ) : (
        <p>לא במלאי</p>
      )}
    </div>
  );
}

export default Book;