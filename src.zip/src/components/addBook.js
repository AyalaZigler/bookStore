// import React, { useState } from 'react';
// import categories from '../categories';
// import './addBook.css';

// function AddBook({ onAddBook }) {
//   const [name, setName] = useState('');
//   const [author, setAuthor] = useState('');
//   const [price, setPrice] = useState('');
//   const [discount, setDiscount] = useState('');
//   const [b_count, setBCount] = useState('');
//   const [category, setCategory] = useState([]);

//   const toggleCategory = (value) => {
//     setCategory(prev =>
//       prev.includes(value) ? prev.filter(c => c !== value) : [...prev, value]
//     );
//   };

//   const send = () => {
//     const newBook = {
//       name,
//       author: author.trim() === '' ? 'אנונימי' : author,
//       price,
//       discount,
//       b_count,
//       category,
//       rating:0,
//       ratingCount: 0
//     };

//     onAddBook(newBook);
//     setName('');
//     setAuthor('');
//     setPrice('');
//     setDiscount('');
//     setBCount('');
//     setCategory([]);
//   };

//   return (
//     <div className='add-wrapper'>
//     <div className="add-book-container">
//       <h3>הוספת ספר חדש</h3>
//       <div><input value={name} onChange={(e) => setName(e.target.value)} placeholder="שם הספר" /></div>
//       <div><input value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="שם הסופר" /></div>
//       <div><input value={price} type="number" onChange={(e) => setPrice(Number(e.target.value))} placeholder="מחיר" /></div>
//       <div><input value={discount} type="number" onChange={(e) => setDiscount(Number(e.target.value))} placeholder="הנחה %" /></div>
//       <div><input value={b_count} type="number" onChange={(e) => setBCount(Number(e.target.value))} placeholder="כמות במלאי" /></div>

//       <div className="category-checks">
//         {Object.entries(categories).map(([key, label]) => (
//           <label key={key}>
//             <input
//               type="checkbox"
//               value={key}
//               checked={category.includes(key)}
//               onChange={() => toggleCategory(key)}
//             />
//             {label}
//           </label>
//         ))}
//       </div>

//       <button onClick={send}>הוסף</button>
//     </div>
//     </div>
//   );
// }

// export default AddBook;
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import categories from '../categories';
import './addBook.css';

function AddBook({ onAddBook }) {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [author, setAuthor] = useState('');
  const [price, setPrice] = useState('');
  const [discount, setDiscount] = useState('');
  const [b_count, setBCount] = useState('');
  const [category, setCategory] = useState([]);

  const toggleCategory = (value) => {
    setCategory(prev =>
      prev.includes(value) ? prev.filter(c => c !== value) : [...prev, value]
    );
  };

  const send = () => {
    // בדיקה שהשדות החובה מלאים
    if (!name.trim()) {
      alert('חובה למלא שם ספר');
      return;
    }
    if (!price || price <= 0) {
      alert('חובה למלא מחיר תקין');
      return;
    }

    const newBook = {
      name: name.trim(),
      author: author.trim() === '' ? 'אנונימי' : author.trim(),
      price: Number(price),
      discount: Number(discount) || 0,
      b_count: Number(b_count) || 0,
      category,
      rating: 0,
      ratingCount: 0
    };

    onAddBook(newBook);
    
    // איפוס השדות
    setName('');
    setAuthor('');
    setPrice('');
    setDiscount('');
    setBCount('');
    setCategory([]);

    // הודעת הצלחה ומעבר לעמוד הספרים
    alert('הספר נוסף בהצלחה!');
    navigate('/books');
  };

  return (
    <div className='add-wrapper'>
      <div className="add-book-container">
        <h3>הוספת ספר חדש</h3>
        <div><input value={name} onChange={(e) => setName(e.target.value)} placeholder="שם הספר *" /></div>
        <div><input value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="שם הסופר" /></div>
        <div><input value={price} type="number" onChange={(e) => setPrice(e.target.value)} placeholder="מחיר *" /></div>
        <div><input value={discount} type="number" onChange={(e) => setDiscount(e.target.value)} placeholder="הנחה %" /></div>
        <div><input value={b_count} type="number" onChange={(e) => setBCount(e.target.value)} placeholder="כמות במלאי" /></div>
        <div className="category-checks">
          {Object.entries(categories).map(([key, label]) => (
            <label key={key}>
              <input
                type="checkbox"
                value={key}
                checked={category.includes(key)}
                onChange={() => toggleCategory(key)}
              />
              {label}
            </label>
          ))}
        </div>
        <button onClick={send}>הוסף</button>
      </div>
    </div>
  );
}

export default AddBook;